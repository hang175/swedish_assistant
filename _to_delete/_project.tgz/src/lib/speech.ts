/** Swedish text-to-speech through the browser's built-in Web Speech API. */
import { useEffect, useState } from 'react';
import { getState } from './store';

const synth: SpeechSynthesis | undefined = typeof window !== 'undefined' ? window.speechSynthesis : undefined;

export function swedishVoices(): SpeechSynthesisVoice[] {
  if (!synth) return [];
  return synth
    .getVoices()
    .filter((v) => v.lang.toLowerCase().replace('_', '-').startsWith('sv'))
    .sort((a, b) => score(b) - score(a));
}
// "Natural"/online voices (Edge) sound much better than the classic local ones
const score = (v: SpeechSynthesisVoice) => (/natural|online/i.test(v.name) ? 2 : 0) + (v.localService ? 0 : 1);

/** undefined while the browser is still loading its voice list */
export function useSwedishVoices(): SpeechSynthesisVoice[] | undefined {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[] | undefined>(undefined);
  useEffect(() => {
    if (!synth) {
      setVoices([]);
      return;
    }
    const update = () => setVoices(swedishVoices());
    if (synth.getVoices().length) update();
    synth.addEventListener('voiceschanged', update);
    // some browsers never fire voiceschanged when the list is empty
    const t = setTimeout(update, 1500);
    return () => {
      synth.removeEventListener('voiceschanged', update);
      clearTimeout(t);
    };
  }, []);
  return voices;
}

export function speak(text: string): void {
  if (!synth || !text) return;
  const { rate, voiceURI } = getState().settings;
  const voices = swedishVoices();
  const voice = voices.find((v) => v.voiceURI === voiceURI) ?? voices[0];
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = voice?.lang ?? 'sv-SE';
  if (voice) u.voice = voice;
  u.rate = rate;
  synth.speak(u);
}

/** What to read aloud for a word: nouns get their article, verbs their infinitive marker is left out. */
export const spokenForm = (w: { w: string; g?: string }) => (w.g === 'en' || w.g === 'ett' ? `${w.g} ${w.w}` : w.w);
